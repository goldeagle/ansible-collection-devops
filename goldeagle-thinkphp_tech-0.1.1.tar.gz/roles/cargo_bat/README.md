# Ansible Role: bat

[![Build Status](https://travis-ci.org/geerlingguy/ansible-role-php-mysql.svg?branch=master)](https://travis-ci.org/geerlingguy/ansible-role-php-mysql)

A replacement of "cat"

Installs bat (https://www.mysql.com/) support on Linux.

## Requirements

None.

## Role Variables

NONE

## Dependencies

NONE

## Example Playbook

    - hosts: all
      roles:
        - { role: goldeagle.bat }

## License

Apache-2.0

## Author Information

Bison 'goldeagle' Fan
