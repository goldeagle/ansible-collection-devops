# Ansible Role: Vsftpd

[![Build Status](https://travis-ci.org/geerlingguy/ansible-role-php-mysql.svg?branch=master)](https://travis-ci.org/geerlingguy/ansible-role-php-mysql)

Installs Vsftpd (https://www.mysql.com/) support on Linux.

## Requirements

None.

## Role Variables

NONE

## Dependencies

NONE

## Example Playbook

    - hosts: dashserver
      roles:
        - { role: goldeagle.vsftpd }

## License

Apache-2.0

## Author Information

Bison 'goldeagle' Fan
